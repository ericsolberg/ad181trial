sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("customerloyalty.purchases.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);